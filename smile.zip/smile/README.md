# WhatsApp-Bot

# Last update!
Cape bruh:v

# BuildPack Heroku🗿

• [`FFMPEG`](https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest.git)

• [`IMAGEMAGICK`](https://github.com/DuckyTeam/heroku-buildpack-imagemagick.git)

• [`WEBP`](https://github.com/clhuang/heroku-buildpack-webp-binaries)

# Contact🗿

• [`About Me`](https://Franky404.github.io/about)

• [`Whatsapp`](https://wa.me/6283183586629?text=halo+bang)

 
# Thanks🗿

• [`Baileys`](https://github.com/adiwajshing/baileys)

• [`MhankBarBar`](https://github.com/MhankBarBar)

• [`Nino-Chan02`](https://github.com/nino-chan02)

• [`Ikyads`](https://github.com/rizkiadiasa)

• [`Galang`](https://github.com/zobin33)

• [`Hexagonz`](https://github.com/Hexagonz)

• [`Rizky`](https://github.com/Rizky878)

• [`Pengguna Bot`]


# 🗿🤘🏻
